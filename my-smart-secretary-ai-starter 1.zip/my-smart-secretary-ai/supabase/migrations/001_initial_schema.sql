-- My Smart Secretary AI initial schema. Run in a fresh Supabase project.
create extension if not exists pgcrypto;
create type public.task_status as enum ('pending','in_progress','completed','cancelled');
create type public.priority_level as enum ('low','medium','high');
create type public.work_status as enum ('assigned','accepted','in_progress','completed','overdue');
create table public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text,
 timezone text not null default 'Asia/Kolkata',
 created_at timestamptz not null default now()
);
create table public.contacts (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 full_name text not null, phone text, whatsapp_phone text, email text, category text not null default 'Personal',
 notes text, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.tasks (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 title text not null, details text, due_at timestamptz, reminder_at timestamptz,
 priority public.priority_level not null default 'medium', status public.task_status not null default 'pending',
 completed_at timestamptz, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.follow_ups (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 contact_id uuid references public.contacts(id) on delete set null, title text not null, notes text,
 due_at timestamptz, completed_at timestamptz, created_at timestamptz not null default now()
);
create table public.assigned_work (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 contact_id uuid references public.contacts(id) on delete set null, recipient_name text not null,
 recipient_whatsapp text not null, title text not null, instructions text, deadline timestamptz not null,
 priority public.priority_level not null default 'medium', status public.work_status not null default 'assigned',
 secure_token_hash text, created_at timestamptz not null default now(), completed_at timestamptz
);
create table public.reminders (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 task_id uuid references public.tasks(id) on delete cascade, assigned_work_id uuid references public.assigned_work(id) on delete cascade,
 scheduled_at timestamptz not null, channel text not null check(channel in ('in_app','web_push','whatsapp','mobile_push')),
 status text not null default 'scheduled', sent_at timestamptz, dedupe_key text unique, created_at timestamptz not null default now()
);
create table public.subscriptions (
 user_id uuid primary key references auth.users(id) on delete cascade, plan_code text not null default 'basic_49',
 status text not null default 'trial', current_period_start timestamptz, current_period_end timestamptz,
 razorpay_subscription_id text, created_at timestamptz not null default now()
);
create table public.usage_counters (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 period_start date not null, metric text not null, used integer not null default 0 check(used>=0),
 unique(user_id,period_start,metric)
);
create table public.notification_logs (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 reminder_id uuid references public.reminders(id) on delete set null, channel text not null,
 provider_message_id text, status text not null, error_message text, created_at timestamptz not null default now()
);
-- Row-level security: each account can only access its own records.
do $$ declare t text; begin foreach t in array array['profiles','contacts','tasks','follow_ups','assigned_work','reminders','subscriptions','usage_counters','notification_logs'] loop execute format('alter table public.%I enable row level security',t); execute format('create policy "owner manages own rows" on public.%I for all using (auth.uid() = user_id) with check (auth.uid() = user_id)',t); end loop; end $$;
create policy "owner manages own profile" on public.profiles for all using (auth.uid()=id) with check (auth.uid()=id);
