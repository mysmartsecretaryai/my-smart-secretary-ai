# My Smart Secretary AI — implementation notes

## Product scope (v1)
- Dashboard, personal tasks, people/contacts, follow-ups, AI Secretary, sound-capable notifications, daily briefings, assigned work via WhatsApp without recipient app installation, usage and subscription screen.
- Basic plan target: ₹49/month.
- Monthly limits: 100 contacts; 100 AI questions; 100 AI task-creation operations; 30 outbound WhatsApp messages; 30 assigned-work items; 100 follow-up records; unlimited personal tasks and in-app reminders; six months of task history.
- 80% usage warning; at 100%, pause that metered feature while keeping manual tasks and in-app notifications available.
- All times use Asia/Kolkata by default; users may change timezone later.

## Important implementation rules
1. Count every outbound WhatsApp message against the 30-message monthly quota. A work assignment is a separate 30-item quota.
2. Do not send WhatsApp messages until the business has an approved WhatsApp Business Platform setup, suitable approved templates where required, and recipient opt-in.
3. Never expose Supabase service-role keys, OpenAI keys, or Razorpay secrets in browser code.
4. Use signed, expiring, single-purpose web links for recipients to acknowledge or complete assigned work. Do not expose the owner's other tasks or contacts.
5. Notification sounds are controlled by browser/mobile OS permissions and platform restrictions; never promise sound playback when the app/browser is closed on every device.
6. Implement server-side idempotency for reminder dispatch and usage increments to prevent duplicate sends/counting.
7. Store only necessary personal information; provide privacy notice, consent, account deletion/export, and secure retention controls.

## Local start
1. Install Node.js 20+.
2. Copy `.env.example` to `.env.local` and fill Supabase values.
3. Run `npm install` then `npm run dev`.
4. Create a Supabase project and run `supabase/migrations/001_initial_schema.sql` in its SQL editor.

## Still required before production
- Supabase project and authentication configuration.
- Server actions/API routes for CRUD, RLS-aware access and monthly usage enforcement.
- OpenAI integration with prompt safety, request caps and cost monitoring.
- WhatsApp Business Platform onboarding, templates, opt-in capture, webhook and delivery logging.
- Razorpay checkout/webhook and subscription lifecycle.
- Push notification service worker, VAPID keys, APNs/FCM configuration and tested sound behaviour.
- Scheduled jobs for reminders and morning/evening briefings.
- Recipient secure status-update endpoint with expiring tokens.
- Automated tests, security review, privacy policy/terms, backups, monitoring and deployment.
- Capacitor packaging, app icons, signing, Apple/Google developer accounts and store review.

This repository is a real development starter, not a deployed production service. The visible pages are an initial UI scaffold; live data, billing, AI, WhatsApp and scheduled notifications require the integrations above.
