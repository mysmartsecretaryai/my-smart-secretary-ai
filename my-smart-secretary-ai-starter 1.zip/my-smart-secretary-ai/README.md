# My Smart Secretary AI

Next.js + TypeScript starter for the personal productivity and delegated-work product.

See `docs/IMPLEMENTATION.md` for product limits, setup, production requirements and known platform constraints.
