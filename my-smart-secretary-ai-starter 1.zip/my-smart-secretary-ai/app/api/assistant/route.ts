import { NextRequest, NextResponse } from 'next/server';
export async function GET(req:NextRequest){const q=req.nextUrl.searchParams.get('q')??'';return NextResponse.json({message:'AI endpoint scaffold is ready. Configure authentication, Supabase usage metering and OPENAI_API_KEY before enabling live AI.',received_question:q,limit_per_month:100});}
