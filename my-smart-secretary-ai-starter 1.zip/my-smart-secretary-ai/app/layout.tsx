import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'My Smart Secretary AI', description: 'Your personal task and work reminder assistant', manifest: '/manifest.webmanifest' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="en"><body>{children}</body></html>; }
